"""Unified session — a pluggable agent brain with an inbox.

Every session is identical: a :class:`~bobi.brain.BrainSession` (Claude
Code by default; see epic #485) connected to an inbox drain loop. The session
drives the brain through the provider-agnostic ``connect`` / ``query`` /
``receive_response`` / ``disconnect`` contract and consumes normalized
``AssistantText`` / ``TurnResult`` messages — never a vendor SDK's classes.
Each session subscribes to its own ``inbox/<self>`` topic on the
event server and injects arriving messages into the Claude session in order.
The only difference between a "manager" and an "agent" is what extra topics it
subscribes to (the manager also subscribes to external resource topics).
"""

from __future__ import annotations

import asyncio
import hashlib
import logging
import os
import queue
import time
import threading
from pathlib import Path

from bobi.brain import AssistantText, TurnResult, get_brain
from bobi.inbox import Inbox, Message
from bobi.sdk import (
    save_session_id,
    load_session_id,
    load_resumable_session_id,
    log_activity,
    get_registry,
    SessionEntry,
)

log = logging.getLogger(__name__)

# Default rotation cap — absolute context-fill tokens, not a window fraction.
DEFAULT_ROTATION_TOKEN_CAP = 275_000

# Rotation reconnect bounds (#456, wedge mechanism #3). Rotation builds a fresh
# client with ``connect(None)`` and swaps it in between inbox turns. A promptless
# connect opens the transport but does NOT create a model turn, so there is no
# response stream to drain (#799). The connect itself remains bounded and
# retryable, and failed candidates are discarded with bounded cleanup. Keep the
# connect timeout above Claude's initialize deadline so the adapter can surface
# retryable initialize timeouts instead of being preempted by this outer bound.
ROTATION_RECONNECT_TIMEOUT = 240.0
ROTATION_MAX_RECONNECT_ATTEMPTS = 3
ROTATION_RECONNECT_BACKOFF = 2.0
ROTATION_DISCONNECT_TIMEOUT = 10.0
MESSAGE_ACK_TIMEOUT = 10.0
ACK_WORKER_STOP_TIMEOUT = 0.1

# Control sentinel for the named compact command (#433). Delivered as an inbox
# message body; the run loop recognizes it, flags rotation, and never forwards
# it to the model. An exact-match constant, so a human message can't trip it.
COMPACT_SENTINEL = "\x00__bobi_compact__\x00"


def _context_fill_tokens(usage: dict | None) -> int:
    """True context-window fill for a turn.

    The prompt sent to the model is ``input_tokens`` (uncached) +
    ``cache_read_input_tokens`` (the cached prefix) +
    ``cache_creation_input_tokens`` (newly cached this turn). With prompt
    caching on, almost the whole conversation lands in ``cache_read`` and
    ``input_tokens`` alone is a wildly low proxy — which is why the old
    rotation check (input_tokens only) never fired and the manager ran to
    ~424K. Sum all three for the real fill.
    """
    if not usage:
        return 0
    return (
        (usage.get("input_tokens") or 0)
        + (usage.get("cache_read_input_tokens") or 0)
        + (usage.get("cache_creation_input_tokens") or 0)
    )


def _rotation_error_message(err: BaseException | None) -> str:
    """Return a non-empty, diagnosable rotation failure string.

    ``asyncio.TimeoutError`` commonly has no message, so ``str(err)`` is empty.
    Rotation failure records are operational breadcrumbs; they must name the
    failure class even when the exception object carries no text.
    """
    if err is None:
        return "unknown rotation reconnect failure"

    err_type = type(err).__name__
    try:
        text = str(err).strip()
    except Exception:
        text = ""
    if text:
        message = f"{err_type}: {text}"
    elif isinstance(err, asyncio.TimeoutError):
        message = (
            f"{err_type}: rotation reconnect timed out after "
            f"{ROTATION_RECONNECT_TIMEOUT:.0f}s"
        )
    else:
        message = f"{err_type}: no error message provided"

    cause = err.__cause__ or err.__context__
    if cause is not None and cause is not err:
        try:
            cause_text = str(cause).strip()
        except Exception:
            cause_text = ""
        cause_text = cause_text or "no error message provided"
        message = f"{message}; caused by {type(cause).__name__}: {cause_text}"
    return message


# Substrings that mark a drain exception as a per-message decode/framing error
# (an oversized or malformed NDJSON line) rather than a dead transport. The SDK
# converts a ``CLIJSONDecodeError`` — including the >max_buffer_size case — into
# a plain ``Exception`` whose text it forwards through the message stream
# (claude_agent_sdk `_read_messages`), so classifying on the message text is the
# reliable cross-version signal.
_DECODE_ERROR_MARKERS = (
    "exceeded maximum buffer size",
    "failed to decode json",
    "jsondecodeerror",
    "json decode",
)


def _is_decode_error(exc: BaseException) -> bool:
    """True when a drain failure is a recoverable per-message decode error.

    A single oversized/garbled NDJSON line is line-framed and recoverable — it
    must not be treated like a dead transport and kill the session (#719). The
    generous ``max_buffer_size`` (bobi.brain.claude, #719) makes the buffer case
    rare; this is the belt-and-suspenders classifier for the residual case.
    """
    try:
        from claude_agent_sdk import CLIJSONDecodeError

        if isinstance(exc, CLIJSONDecodeError):
            return True
    except Exception:
        pass
    text = str(exc).lower()
    return any(marker in text for marker in _DECODE_ERROR_MARKERS)

# Background event-subscription retry cadence (#409). When the initial
# registration handshake with the event server times out, the session boots
# anyway and a daemon thread keeps retrying with capped exponential backoff —
# events are queued/sequenced/resumable, so a late registration just resumes
# the stream from the saved cursor.
SUBSCRIPTION_RETRY_BASE = 2.0
SUBSCRIPTION_RETRY_MAX = 60.0

# In-band retry for transient turn-level API errors (e.g. 529 Overloaded, rate
# limits). A transient error is scoped to a single turn — the SDK client stays
# connected — so we re-issue the same query with capped exponential backoff
# before giving up. This must never leave the session terminally wedged: see
# _drain_turn / _process_message. Retries are bounded so a genuinely failing
# turn surfaces its error to the caller instead of looping forever.
#
# The retry budget and the "what counts as transient" set/classifier live in
# bobi.transient so the sub-agent spawn/executor path agrees on the same
# definition (MDS-65, §4.3). Re-imported here for back-compat — existing call
# sites and tests reference these names off bobi.session.
from bobi.transient import (  # noqa: F401  (re-exported for back-compat)
    TURN_RETRY_BASE,
    TURN_RETRY_MAX_ATTEMPTS,
    TRANSIENT_API_STATUSES,
    is_transient_api_error,
)

# Liveness guard for queued work while a session is temporarily not ready
# (active turn, rotation, reconnect, or recovery). The message must remain
# queued until the session recovers; after this window, emit a best-effort
# operator alert so the stuck state is visible.
SESSION_UNREACHABLE_ALERT_AFTER = 120.0
SESSION_READY_WAIT_POLL = 1.0

# Heartbeat cadence for the in-flight-turn keepalive (#721). While a turn is
# blocked in receive_response() — e.g. parked on a Task subagent that outlives
# the wedge threshold — _drain_turn makes no registry writes, so last_activity
# freezes at turn start and any liveness check reading {status, last_activity,
# idle_seconds} cannot tell "healthy, blocked on a live child" from "wedged."
# The keepalive refreshes last_activity on this cadence, driven by the event
# loop itself. It must sit well below the wedge stall threshold (default 600s,
# and as high as 2400s in the field) so a healthy turn never crosses it; 30s
# also matches the ~30s window over which the supervisor confirms a stall.
KEEPALIVE_INTERVAL = 30.0


def _emit_session_unreachable_alert(
    *,
    session: str,
    state: str,
    message_id: str,
    sender: str,
    wait: bool,
    elapsed: float,
) -> None:
    """Emit a best-effort alert for a queued message stuck behind readiness."""
    try:
        from bobi.events.publish import post_event
        post_event(
            "system/session.unreachable",
            {
                "session": session,
                "state": state,
                "message_id": message_id,
                "sender": sender,
                "wait": wait,
                "elapsed_seconds": round(elapsed, 1),
                "text": (
                    f"Session '{session}' has been unreachable for "
                    f"{elapsed:.0f}s while a queued message waits; current "
                    f"state: {state}."
                ),
            },
        )
    except Exception:
        log.warning("Failed to emit session unreachable alert", exc_info=True)


def _ack_message(msg: Message) -> None:
    """Confirm a fully-processed message so its event-server cursor advances.

    Only called on paths where the message was actually processed (#688) -
    a dropped or failed message must not ack, so a restart replays it.
    Ack failure is non-fatal: the cursor stays behind and the event is
    re-delivered after a restart (at-least-once).
    """
    if msg.on_done is None:
        return
    try:
        msg.on_done()
    except Exception:
        log.warning("Message ack failed for %s", msg.id, exc_info=True)


def _consume_task_result(task: asyncio.Task) -> None:
    """Retrieve a detached cleanup task's result to avoid warning noise."""
    try:
        task.result()
    except asyncio.CancelledError:
        pass
    except Exception:
        pass


def _track_detached_task(
    task: asyncio.Task,
    detached_tasks: set[asyncio.Task] | None,
) -> None:
    """Retain timed-out work until it exits after adapter cleanup."""
    if detached_tasks is not None:
        detached_tasks.add(task)
        task.add_done_callback(detached_tasks.discard)
    task.add_done_callback(_consume_task_result)


def _complete_ack_future(done: asyncio.Future) -> None:
    """Resolve an ACK wait if its event loop is still accepting callbacks."""
    if not done.done():
        done.set_result(None)


async def _await_with_hard_timeout(
    awaitable,
    timeout: float,
    name: str,
    detached_tasks: set[asyncio.Task] | None = None,
):
    """Await work for at most ``timeout``, even if it suppresses cancellation."""
    task = asyncio.create_task(awaitable, name=name)
    try:
        done, _ = await asyncio.wait({task}, timeout=timeout)
    except BaseException:
        task.cancel()
        asyncio.get_running_loop().call_soon(task.cancel)
        _track_detached_task(task, detached_tasks)
        raise

    if done:
        return task.result()

    # asyncio.wait_for waits for cancellation cleanup and is therefore not a
    # hard deadline when a buggy adapter suppresses CancelledError. Detach the
    # task after two cancellation signals so lifecycle work can recover loudly
    # within its advertised bound.
    task.cancel()
    asyncio.get_running_loop().call_soon(task.cancel)
    _track_detached_task(task, detached_tasks)
    raise asyncio.TimeoutError()


class Session:
    """A Claude Code session with an inbox for receiving messages."""

    def __init__(
        self,
        name: str,
        cwd: str,
        system_prompt: dict | None = None,
        on_response=None,
        extra_options: dict | None = None,
        role: str = "engineer",
        subscribe: list[str] | None = None,
    ) -> None:
        self.name = name
        self.cwd = cwd
        self.role = role
        # Extra event topics beyond this session's own inbox/<self> (e.g. the
        # manager's external resource topics). inbox/<self> is always added.
        self._subscribe = list(subscribe or [])
        self.inbox = Inbox(name)
        self._system_prompt = system_prompt or {
            "type": "preset",
            "preset": "claude_code",
        }
        self._on_response = on_response
        opts = extra_options or {}
        self._rotation_token_cap = opts.pop("rotation_token_cap", DEFAULT_ROTATION_TOKEN_CAP)
        self._extra_options = opts

        # The agent brain (Claude Code by default). A factory: every fresh
        # connect/rotation/recovery builds a new BrainSession from it (#485).
        self._brain = get_brain()
        self._client = None
        self._subscription = None
        self._sub_retry_stop = threading.Event()
        self._sub_retry_thread: threading.Thread | None = None
        # Guards the hand-off of a background-registered subscription to stop().
        self._sub_lock = threading.Lock()
        self._loop: asyncio.AbstractEventLoop | None = None
        self._thread: threading.Thread | None = None
        self._ready = threading.Event()
        self._keep_alive: asyncio.Event | None = None
        self._input_ready: asyncio.Event | None = None
        self._state = "stopped"
        self._last_response = ""
        self._last_is_error = False
        self._last_api_error_status: int | None = None
        self._total_cost_usd = 0.0
        self._total_duration_ms = 0
        self._total_turns = 0

        # Context rotation state (Steps 1-4, #273). Rotation now cycles the
        # client directly (no decision-log flush — #456 removed it); the only
        # rotation work is the bounded, recoverable reconnect (#456 mech #3).
        self._rotate_pending = False
        self._rotate_reason = "context_cap"
        self._rotation_count = 0
        # Rotation preparation runs beside the inbox loop so a slow/hung fresh
        # connect cannot starve queued human messages. The worker only returns a
        # candidate; the inbox coroutine owns the active-client pointer and
        # commits the swap between complete turns.
        self._rotation_task: asyncio.Task | None = None
        self._retired_client_tasks: set[asyncio.Task] = set()
        self._hard_timeout_tasks: set[asyncio.Task] = set()
        self._ack_queue: queue.Queue[
            tuple[Message, asyncio.AbstractEventLoop, asyncio.Future] | None
        ] = queue.Queue()
        self._ack_worker_thread: threading.Thread | None = None

    def detect_state(self) -> str:
        return self._state

    def _set_state(self, state: str) -> None:
        """Update state and wake any waiter when the session becomes idle or terminal."""
        self._state = state
        if state in ("waiting_input", "stopped", "error") and self._input_ready:
            self._input_ready.set()

    def _is_transient_turn_error(self) -> bool:
        """Whether the last turn's error is worth retrying.

        Thin delegate over the shared classifier (bobi.transient): prefers
        the SDK-reported ``api_error_status`` (e.g. 529); falls back to sniffing
        the response text for overload/rate-limit/timeout phrasing when no status
        was surfaced.
        """
        return is_transient_api_error(
            self._last_api_error_status, self._last_response or ""
        )

    def _stop_status_indicators(self) -> None:
        """Clear any Slack "is thinking…" refresh loops this manager started.

        Normally cleared at the end of a turn (see ``_drain_turn``), but a
        message dropped before it runs a turn (session stopped/error/not ready)
        would otherwise leave the indicator refreshing itself forever.
        """
        try:
            from bobi.events.channels import stop_all_refresh_loops
            stop_all_refresh_loops()
        except Exception:
            pass

    # -----------------------------------------------------------------
    # Context rotation (Steps 1, 4 — #273)
    # -----------------------------------------------------------------

    def _make_brain_session(self, resume: str | None = None):
        """Build a fresh brain session (boot, rotation reconnect, recovery).

        ``resume=None`` yields a clean fresh-connect session; pass a saved id to
        resume. Brain-specific extras (skills, max_turns, mcp_servers, …) ride
        ``_extra_options``; the adapter supplies the shared defaults
        (``permission_mode``, ``cli_path``).
        """
        from bobi.runtime_guard import prepare_brain_runtime

        prepare_brain_runtime()
        return self._brain.make_session(
            cwd=self.cwd,
            system_prompt=self._system_prompt,
            resume=resume,
            options=self._extra_options,
        )

    def _session_model(self) -> str:
        """The effective configured model for this session (#617).

        The explicit option if set, else the process default the adapter
        would fill in - the string recorded alongside the saved session id
        so a resume under a different model starts fresh instead.
        """
        from bobi.brain import resolve_model_option
        return resolve_model_option(self._extra_options.get("model"))

    async def _safe_disconnect(self, client) -> None:
        """Disconnect a brain client without letting cleanup wedge lifecycle."""
        try:
            await _await_with_hard_timeout(
                client.disconnect(),
                ROTATION_DISCONNECT_TIMEOUT,
                f"disconnect-{self.name}",
                self._hard_timeout_tasks,
            )
        except asyncio.TimeoutError:
            self._force_abort_client(client, "disconnect timeout")
            log.warning(
                "Disconnect for '%s' timed out after %.0fs during cleanup; "
                "discarding the client",
                self.name,
                ROTATION_DISCONNECT_TIMEOUT,
            )
        except asyncio.CancelledError:
            self._force_abort_client(client, "cancelled disconnect")
            raise
        except Exception:
            self._force_abort_client(client, "disconnect failure")
            log.debug("Disconnect raised for '%s' during cleanup", self.name,
                      exc_info=True)

    def _force_abort_client(self, client, reason: str) -> None:
        """Invoke the brain contract's synchronous last-resort cleanup path."""
        abort = getattr(client, "abort", None)
        if not callable(abort):
            log.error(
                "Brain client for '%s' has no force-abort hook after %s",
                self.name,
                reason,
            )
            return
        try:
            abort()
        except Exception:
            log.error(
                "Brain client force-abort failed for '%s' after %s",
                self.name,
                reason,
                exc_info=True,
            )

    async def _attempt_reconnect(self):
        """Build and connect one fresh rotation candidate under a hard bound.

        ``BrainSession.connect(None)`` opens a session without sending input, so
        it creates no turn and there is deliberately no ``receive_response``
        call here. The old code drained that nonexistent turn and made every
        successful Claude reconnect look hung for 240 seconds (#799).

        The candidate is not published through ``self._client``. The inbox loop
        remains the single owner of that pointer and swaps only between turns.
        """
        client = self._make_brain_session(resume=None)

        try:
            await _await_with_hard_timeout(
                client.connect(),
                ROTATION_RECONNECT_TIMEOUT,
                f"rotation-connect-attempt-{self.name}",
                self._hard_timeout_tasks,
            )
        except BaseException:
            # Discard the partially-connected client before retrying so each
            # attempt owns one subprocess.
            self._force_abort_client(client, "rotation connect failure")
            await self._safe_disconnect(client)
            raise
        return client

    async def _prepare_rotation(self):
        """Connect a fresh candidate without disturbing the active client.

        Production starts this as a background task. The old client remains
        usable while a slow candidate connects, so queued messages continue to
        drain. This worker never assigns ``self._client``; the inbox coroutine
        commits its returned candidate between complete turns.
        """
        log.info("Rotating session '%s' (rotation #%d)", self.name, self._rotation_count + 1)
        reason = self._rotate_reason

        # Rebuild system prompt - reloads long-term memory (#456).
        self._system_prompt = self._rebuild_system_prompt()

        # Bounded, recoverable reconnect.
        last_err: BaseException | None = None
        attempt_errors: list[dict] = []
        candidate = None
        for attempt in range(1, ROTATION_MAX_RECONNECT_ATTEMPTS + 1):
            try:
                candidate = await self._attempt_reconnect()
                break
            except asyncio.TimeoutError as e:
                last_err = e
                attempt_errors.append({
                    "attempt": attempt,
                    "error": _rotation_error_message(e),
                })
                log.error(
                    "Rotation reconnect for '%s' timed out after %.0fs "
                    "(attempt %d/%d)",
                    self.name, ROTATION_RECONNECT_TIMEOUT, attempt,
                    ROTATION_MAX_RECONNECT_ATTEMPTS,
                )
            except Exception as e:
                last_err = e
                attempt_errors.append({
                    "attempt": attempt,
                    "error": _rotation_error_message(e),
                })
                log.error(
                    "Rotation reconnect for '%s' failed (attempt %d/%d): %s",
                    self.name, attempt, ROTATION_MAX_RECONNECT_ATTEMPTS,
                    _rotation_error_message(e),
                )
            if attempt < ROTATION_MAX_RECONNECT_ATTEMPTS:
                await asyncio.sleep(ROTATION_RECONNECT_BACKOFF * attempt)

        if candidate is None:
            # Exhausted — recover into an addressable state (or surface
            # terminally if even that fails). Raises on terminal failure.
            candidate = await self._recover_rotation_failure(
                last_err, attempt_errors
            )

        return candidate, reason

    def _retire_client(self, client) -> None:
        """Disconnect a replaced client in tracked, bounded background work."""
        if client is None:
            return
        task = asyncio.create_task(
            self._safe_disconnect(client),
            name=f"rotation-retire-{self.name}",
        )
        self._retired_client_tasks.add(task)
        task.add_done_callback(self._retired_client_tasks.discard)

    async def _commit_rotation(self, candidate, reason: str) -> None:
        """Swap a connected candidate in between inbox turns."""
        old_client = self._client

        # Clear resumability only once the replacement is ready. Clearing this
        # before background preparation would make a failed rotation destroy a
        # still-usable old session on process restart.
        save_session_id(self.name, "")
        self._client = candidate
        self._set_state("waiting_input")
        self._rotate_pending = False
        self._rotate_reason = "context_cap"
        self._rotation_count += 1
        self._retire_client(old_client)

        # Step 6: Observability - log rotation event.
        log_activity(
            "rotation",
            {
                "count": self._rotation_count,
                "reason": reason,
            },
            session=self.name,
        )
        # Also emit to events.jsonl via the event client
        try:
            from bobi.events.client import _log_event
            _log_event(
                {
                    "type": "session.rotated",
                    "source": "bobi",
                    "payload": {
                        "session": self.name,
                        "rotation_count": self._rotation_count,
                        "reason": reason,
                    },
                },
                session_id=self.name,
            )
        except Exception:
            pass

        registry = get_registry()
        registry.update(self.name, status="idle", rotation_count=self._rotation_count)
        log.info("Session '%s' rotated successfully (count=%d)", self.name, self._rotation_count)

    async def _rotate(self) -> None:
        """Prepare and commit a rotation inline (unit/back-compat helper).

        The production inbox path uses ``_prepare_rotation`` as background work
        and calls ``_commit_rotation`` itself. Keeping this wrapper preserves
        direct callers and the bounded/loud rotation policy tests.
        """
        try:
            candidate, reason = await self._prepare_rotation()
        except Exception:
            self._rotate_pending = False
            self._set_state("error")
            get_registry().update(self.name, status="error")
            raise
        try:
            await self._commit_rotation(candidate, reason)
        except BaseException:
            if self._client is not candidate:
                await self._safe_disconnect(candidate)
            raise

    async def _recover_rotation_failure(
        self,
        err: BaseException | None,
        attempt_errors: list[dict] | None = None,
    ):
        """Recover after the bounded reconnect exhausted its attempts (#456 #3).

        Fails loudly (log.error + a session.rotation_failed activity/event) and
        then returns a fresh connected candidate. The active client is left
        untouched until the inbox loop commits that candidate. Only if even
        this final fresh connect fails does the session surface terminally,
        loudly, never as a silent hang.
        """
        error_message = _rotation_error_message(err)
        attempt_errors = attempt_errors or [
            {"attempt": ROTATION_MAX_RECONNECT_ATTEMPTS, "error": error_message}
        ]

        log.error(
            "Rotation reconnect exhausted for '%s' after %d attempts: %s — "
            "attempting fresh-connect recovery",
            self.name, ROTATION_MAX_RECONNECT_ATTEMPTS, error_message,
        )
        try:
            log_activity(
                "rotation_failed",
                {
                    "attempts": ROTATION_MAX_RECONNECT_ATTEMPTS,
                    "error": error_message,
                    "attempt_errors": attempt_errors,
                },
                session=self.name,
            )
            from bobi.events.client import _log_event
            _log_event(
                {
                    "type": "session.rotation_failed",
                    "source": "bobi",
                    "payload": {
                        "session": self.name,
                        "attempts": ROTATION_MAX_RECONNECT_ATTEMPTS,
                        "error": error_message,
                        "attempt_errors": attempt_errors,
                    },
                },
                session_id=self.name,
            )
        except Exception:
            pass

        # Final recovery is still fresh and promptless. It is independently
        # bounded, and it does not disturb the active client unless it succeeds
        # and the inbox coroutine later commits it.
        client = self._make_brain_session(resume=None)
        try:
            await _await_with_hard_timeout(
                client.connect(),
                ROTATION_RECONNECT_TIMEOUT,
                f"rotation-connect-recovery-{self.name}",
                self._hard_timeout_tasks,
            )
        except asyncio.CancelledError:
            # Session shutdown cancels background preparation. It is not a
            # terminal reconnect failure and must not emit false recovery
            # alarms or temporarily mark the stopping session as errored.
            self._force_abort_client(client, "cancelled recovery connect")
            await self._safe_disconnect(client)
            raise
        except BaseException as e2:
            self._force_abort_client(client, "recovery connect failure")
            await self._safe_disconnect(client)
            final_error_message = _rotation_error_message(e2)
            try:
                log_activity(
                    "rotation_failed",
                    {
                        "attempts": ROTATION_MAX_RECONNECT_ATTEMPTS,
                        "error": error_message,
                        "attempt_errors": attempt_errors,
                        "final_recovery_error": final_error_message,
                    },
                    session=self.name,
                )
                from bobi.events.client import _log_event
                _log_event(
                    {
                        "type": "session.rotation_failed",
                        "source": "bobi",
                        "payload": {
                            "session": self.name,
                            "attempts": ROTATION_MAX_RECONNECT_ATTEMPTS,
                            "error": error_message,
                            "attempt_errors": attempt_errors,
                            "final_recovery_error": final_error_message,
                        },
                    },
                    session_id=self.name,
                )
            except Exception:
                pass
            log.error(
                "Final rotation recovery failed for '%s': %s — surfacing terminally",
                self.name, final_error_message,
            )
            raise
        log.warning(
            "Session '%s' recovered to a fresh connected client after a failed "
            "rotation — addressable, not wedged", self.name,
        )
        return client

    def _rebuild_system_prompt(self) -> dict:
        """Rebuild the system prompt, reloading long-term memory (#456).

        A rotated session re-reads long_term_memory.md here - the passive
        pickup path for a sleep-cycle update.
        """
        try:
            from bobi.subagent import _load_long_term_memory_prompt
            memory_prompt = _load_long_term_memory_prompt()
            if isinstance(self._system_prompt, dict):
                base_append = self._system_prompt.get("append", "")
                # Strip a previously-injected memory section so it isn't
                # doubled across rotations.
                for heading in ("## Long-Term Memory", "## Team Policy"):
                    if heading in base_append:
                        base_append = base_append.split(heading)[0].rstrip()
                        break
                if memory_prompt:
                    new_append = (
                        f"{base_append}\n\n{memory_prompt}" if base_append else memory_prompt
                    )
                else:
                    new_append = base_append
                return {**self._system_prompt, "append": new_append}
        except Exception:
            log.debug("Failed to reload long-term memory for '%s'", self.name, exc_info=True)
        return self._system_prompt

    async def _keepalive(self, registry) -> None:
        """Refresh last_activity on a timer while a turn is in flight (#721).

        _drain_turn stamps last_activity once at turn start (status="running")
        and then blocks in receive_response() with no intermediate registry
        writes. A Task subagent call parks the director inside that await with
        no messages until the child returns, and deep-research children
        routinely outlive the wedge stall threshold — so for the whole child
        run last_activity stays frozen at turn start. From the outside that is
        byte-identical to a wedge: status="running", idle_seconds climbing past
        threshold. The wedge test (the #464 watchdog and its port in the deploy
        supervisor sidecar) then kills a healthy parent mid-task, because the
        health payload is only {status, last_activity, idle_seconds} with no
        subagent field to distinguish the two.

        This refreshes last_activity on a cadence *driven by the event loop
        itself*, so it is a genuine liveness signal rather than a "a turn was
        started" flag. A director merely blocked on a live child keeps its loop
        pumping, so this coroutine wakes and the session reads alive. A director
        genuinely wedged in-turn — the loop itself not progressing (a
        synchronous hang, not an await) — cannot run this coroutine, so
        last_activity stays frozen and the stall is still detected. The update
        carries no status kwarg, so it only touches last_activity and never
        resurrects a status that the drain loop has since moved to idle/error.
        """
        while True:
            await asyncio.sleep(KEEPALIVE_INTERVAL)
            try:
                registry.update(self.name)
            except Exception:
                # A transient registry-write failure must not kill the heartbeat
                # for the rest of the turn — that would silently re-expose the
                # false wedge. Log and keep beating. (asyncio.CancelledError is a
                # BaseException, so cancellation still tears the task down.)
                log.debug(
                    "keepalive: last_activity refresh failed for '%s'",
                    self.name, exc_info=True,
                )

    async def _drain_turn(self) -> str | None:
        self._last_response = ""
        turn_completed = False
        if self._input_ready:
            self._input_ready.clear()
        self._set_state("working")
        registry = get_registry()
        registry.update(self.name, status="running")

        # Per-call usage from the LAST assistant message in the turn — the
        # single representative API call we measure context fill from (#454).
        # The ResultMessage's usage is the turn AGGREGATE: in a multi-step turn
        # (model → tool → model → …) the cached prefix is re-read on every call,
        # so summing its cache_read counts the context N times (real_context×N)
        # and fires a perpetual false "rotation pending". One call's usage is
        # the actual window fill.
        last_assistant_usage: dict | None = None

        # Heartbeat last_activity for the duration of the turn so a director
        # blocked on a live child (e.g. a Task subagent) is not mistaken for a
        # wedge (#721). Cancelled in the finally below the moment the turn ends.
        keepalive = asyncio.create_task(self._keepalive(registry))

        try:
            async for msg in self._client.receive_response():
                if isinstance(msg, AssistantText):
                    if msg.usage is not None:
                        last_assistant_usage = msg.usage
                    if msg.text:
                        self._last_response = msg.text
                        log_activity(
                            "response",
                            {"text": self._last_response[:500]},
                            session=self.name,
                        )
                        if self._on_response and self._last_response.strip():
                            try:
                                self._on_response(self._last_response)
                            except Exception:
                                pass
                elif isinstance(msg, TurnResult):
                    turn_completed = True
                    save_session_id(self.name, msg.session_id,
                                    model=self._session_model())
                    self._last_is_error = msg.is_error
                    cost = msg.total_cost_usd or 0.0
                    self._total_cost_usd += cost
                    self._total_duration_ms += msg.duration_ms
                    self._total_turns += msg.num_turns
                    # Record cost with the brain's normalized per-model usage
                    # breakdown, attributed to the brain's provider (not a
                    # hardcoded "anthropic" — #485).
                    if cost > 0 or msg.costs:
                        provider = getattr(self._client, "provider", "anthropic")
                        if msg.costs:
                            single_model = len(msg.costs) == 1
                            for c in msg.costs:
                                registry.record_cost(
                                    self.name, cost if single_model else 0.0,
                                    model=c.model,
                                    provider=provider,
                                    input_tokens=c.input_tokens,
                                    output_tokens=c.output_tokens,
                                    cached_input_tokens=c.cached_input_tokens,
                                )
                            if not single_model and cost > 0:
                                registry.record_cost(
                                    self.name, cost, provider=provider,
                                )
                        else:
                            registry.record_cost(
                                self.name, cost, provider=provider,
                            )
                    self._last_api_error_status = msg.api_error_status
                    if msg.is_error:
                        # A turn-level API error (e.g. 529 Overloaded, rate
                        # limit) is transient and scoped to this turn — the SDK
                        # client stays connected. It must NOT drop the session
                        # into the terminal "error" state: _process_message
                        # silently rejects every future message while the state
                        # is "error" and is_alive() reports the session dead, so
                        # a single 529 would deafen the agent until a process
                        # restart (#443). Surface the error but return to ready so the
                        # next event is served (the caller may also retry — see
                        # _process_message).
                        log.error(
                            "Session '%s' turn error (api_status=%s): %s",
                            self.name,
                            self._last_api_error_status,
                            self._last_response[:200],
                        )
                        self._set_state("waiting_input")
                        registry.update(
                            self.name, status="idle", session_id=msg.session_id
                        )
                    else:
                        self._set_state("waiting_input")
                        registry.update(self.name, status="idle", session_id=msg.session_id)
                        # Step 2: Check rotation cap against TRUE context fill,
                        # measured from a SINGLE representative API call (the
                        # last assistant message's usage) — NOT the cumulative
                        # ResultMessage usage, which sums cache_read across every
                        # model call in the turn and over-counts by ×N (#454).
                        # input_tokens alone is the uncached delta (≈0 on a warm
                        # turn) — the conversation lives in cache_read — so we
                        # still sum input + cache_read + cache_creation, just of
                        # that one call.
                        context_tokens = _context_fill_tokens(last_assistant_usage)
                        if context_tokens >= self._rotation_token_cap:
                            log.info(
                                "Session '%s' context=%d tokens exceeds cap=%d — "
                                "rotation pending",
                                self.name, context_tokens, self._rotation_token_cap,
                            )
                            # Over-cap is non-negotiable: the session MUST shed
                            # context. With the decision-log flush removed (#456),
                            # a pending rotation now just cycles the client at the
                            # next idle — nothing to no-op-livelock on.
                            self._rotate_pending = True
                            self._rotate_reason = "context_cap"
        except Exception as e:
            # A drain failure used to be terminal on the FIRST exception: the
            # session dropped to status="error" and stayed dead until a process
            # restart. That is how a single oversized message (the 1 MB buffer
            # death) left a director dead for tens of minutes in #718. Now we
            # distinguish the two kinds of failure (#719):
            if _is_decode_error(e):
                # A per-message decode error — a single oversized/garbled NDJSON
                # line — is line-framed and recoverable. It must NOT kill the
                # session. The SDK reader for THIS connection is spent, so flag a
                # rotation: the bounded, well-tested idle-time _rotate() rebuilds
                # a fresh client, and we return to ready. (max_buffer_size in
                # bobi.brain.claude, #719, makes this case rare; this is the
                # safety net for the residual.) Clearing _last_is_error stops a
                # prior turn's transient-error state from driving a spurious
                # retry now that we return to waiting_input.
                log.error(
                    "Drain hit a recoverable per-message decode error for '%s' "
                    "(rotating client, not killing the session): %s",
                    self.name, e,
                )
                self._last_is_error = False
                self._rotate_pending = True
                self._rotate_reason = "drain_decode_error"
                self._set_state("waiting_input")
                registry.update(self.name, status="idle")
            else:
                # A genuinely dead transport (process gone, broken pipe) stays
                # terminal, as before — a fresh process start recovers it, which
                # the supervisor owns. Recovering it inline would block this
                # session's loop on repeated connect timeouts.
                #
                # The turn did NOT complete, so it must read as a failed turn:
                # run_phase_blocking builds AgentResult.success from
                # _last_is_error — without this a crashed phase records a clean
                # TERMINAL_COMPLETED (#818 D002). The triggering message's
                # no-ack/replay is owned by the None return below (#799/#688).
                log.error(f"Drain failed for '{self.name}': {e}")
                self._last_is_error = True
                if not self._last_response:
                    self._last_response = f"drain failed: {e}"
                self._set_state("error")
                registry.update(self.name, status="error")
        finally:
            keepalive.cancel()
            try:
                await keepalive
            except asyncio.CancelledError:
                pass
            except Exception:
                # Defense in depth: the heartbeat already swallows its own
                # errors, but never let a keepalive failure escape here and mask
                # a drain exception or skip the turn-complete cleanup below.
                log.debug(
                    "keepalive: teardown for '%s' raised", self.name, exc_info=True
                )

        # Turn complete — clear any "is thinking…" indicators the drain loop
        # started for this turn. The gateway clears the indicator when a
        # reply resolves the response context (`bobi reply` sends mode
        # final), but the manager's refresh loop would re-set it on the next
        # tick; this in-process sweep is what actually stops the loops.
        self._stop_status_indicators()

        if not turn_completed:
            # A response stream is not successfully processed until its
            # terminal TurnResult arrives. In particular, a transport error can
            # be caught above after query() succeeds; returning a normal string
            # in that case made _process_message ACK and permanently discard
            # the event. Keep the cursor pinned for replay instead (#799).
            if self._state == "working":
                log.error(
                    "Drain ended without a terminal result for '%s'",
                    self.name,
                )
                self._set_state("error")
                registry.update(self.name, status="error")
            return None

        return self._last_response

    async def _ack_processed(self, msg: Message) -> None:
        """Run ordered message ACKs off the event loop under a hard bound.

        The ack ends in real I/O (cursor-file write + WS send in
        ``ack_through``); a blocked socket must never freeze this session's
        event loop. A dedicated daemon worker preserves callback ordering while
        letting this coroutine return loudly if the I/O exceeds its bound.
        """
        if msg.on_done is None:
            return
        loop = asyncio.get_running_loop()
        done = loop.create_future()
        self._start_ack_worker()
        self._ack_queue.put((msg, loop, done))
        completed, _ = await asyncio.wait({done}, timeout=MESSAGE_ACK_TIMEOUT)
        if not completed:
            log.error(
                "Message ACK for %s in session '%s' timed out after %.0fs; "
                "surfacing terminally with the cursor pinned for replay",
                msg.id,
                self.name,
                MESSAGE_ACK_TIMEOUT,
            )
            self._set_state("error")
            try:
                get_registry().update(self.name, status="error")
            except Exception:
                log.error(
                    "Could not persist terminal ACK timeout state for '%s'",
                    self.name,
                    exc_info=True,
                )

    def _start_ack_worker(self) -> None:
        """Start the session's ordered, daemonized cursor worker lazily."""
        if self._ack_worker_thread is not None:
            return

        def _worker() -> None:
            while True:
                item = self._ack_queue.get()
                if item is None:
                    return
                msg, loop, done = item
                _ack_message(msg)
                try:
                    loop.call_soon_threadsafe(_complete_ack_future, done)
                except RuntimeError:
                    # The session loop already closed. The callback ran, so no
                    # additional cleanup remains in this worker.
                    pass

        self._ack_worker_thread = threading.Thread(
            target=_worker,
            daemon=True,
            name=f"message-ack-{self.name}",
        )
        self._ack_worker_thread.start()

    def _stop_ack_work(self) -> None:
        """Stop the ordered ACK worker without letting a stuck callback wedge."""
        worker = self._ack_worker_thread
        self._ack_worker_thread = None
        if worker is None:
            return
        self._ack_queue.put(None)
        worker.join(timeout=ACK_WORKER_STOP_TIMEOUT)
        if worker.is_alive():
            log.error(
                "Message ACK worker for '%s' is still blocked during shutdown; "
                "leaving the daemon worker detached",
                self.name,
            )

    async def _process_message(self, msg: Message) -> None:
        """Wait for ready state, inject a message, and optionally respond."""
        wait_started = time.monotonic()
        alerted_unreachable = False
        while self._state not in ("waiting_input", "stopped", "error"):
            elapsed = time.monotonic() - wait_started
            if (
                not alerted_unreachable
                and elapsed >= SESSION_UNREACHABLE_ALERT_AFTER
            ):
                _emit_session_unreachable_alert(
                    session=self.name,
                    state=self._state,
                    message_id=msg.id,
                    sender=msg.sender,
                    wait=msg.wait,
                    elapsed=elapsed,
                )
                alerted_unreachable = True
            if self._input_ready:
                if self._input_ready.is_set():
                    # A set event with a still-not-ready state is stale. Do not
                    # clear it here: a real ready transition could race between
                    # the loop condition and this branch. Sleep briefly instead
                    # so stale events cannot spin the loop.
                    await asyncio.sleep(SESSION_READY_WAIT_POLL)
                else:
                    try:
                        await asyncio.wait_for(
                            self._input_ready.wait(),
                            timeout=SESSION_READY_WAIT_POLL,
                        )
                    except asyncio.TimeoutError:
                        pass
            else:
                # Fallback: no event yet (shouldn't happen after _run)
                await asyncio.sleep(SESSION_READY_WAIT_POLL)

        if self._state in ("stopped", "error"):
            # Not ACKed (on_done not called), so the event server replays the
            # message after a restart instead of losing it (#688).
            log.warning(
                "Dropping inbox message for '%s' (state=%s, sender=%s): %.120s",
                self.name, self._state, msg.sender, msg.text,
            )
            # Dropping the message means no turn runs, so clear any Slack
            # "thinking…" indicator here — _drain_turn (which normally clears
            # it) is never reached.
            self._stop_status_indicators()
            if msg.wait:
                self.inbox.respond(msg, f"session {self._state}")
            return

        if self._state != "waiting_input":
            log.warning(f"Session '{self.name}' never became ready for inbox message")
            self._stop_status_indicators()
            if msg.wait:
                self.inbox.respond(msg, "session not ready")
            return

        # Compact control signal — flag a forced rotation and let
        # the idle loop flush + rotate. Never forward it to the model.
        if msg.text == COMPACT_SENTINEL:
            log.info("Session '%s' received compact request — rotation pending", self.name)
            self._rotate_pending = True
            self._rotate_reason = "manual"
            if msg.wait:
                self.inbox.respond(msg, "compaction requested; rotating at next idle")
            await self._ack_processed(msg)
            return

        try:
            log_activity(
                "inbox",
                {"sender": msg.sender, "text": msg.text[:200]},
                session=self.name,
            )
            await self._client.query(msg.text)
            response = await self._drain_turn()

            # Self-heal transient turn errors (529 Overloaded, rate limits):
            # re-issue the same query with capped backoff so the triggering
            # event is answered instead of dropped. Bounded so a persistently
            # failing turn surfaces its error rather than looping forever.
            attempt = 0
            while (
                self._last_is_error
                and self._is_transient_turn_error()
                and attempt < TURN_RETRY_MAX_ATTEMPTS
                and self._state == "waiting_input"
            ):
                delay = TURN_RETRY_BASE * (2 ** attempt)
                attempt += 1
                log.warning(
                    "Session '%s' turn hit transient error (api_status=%s); "
                    "retry %d/%d after %.1fs",
                    self.name, self._last_api_error_status, attempt,
                    TURN_RETRY_MAX_ATTEMPTS, delay,
                )
                if delay:
                    await asyncio.sleep(delay)
                await self._client.query(msg.text)
                response = await self._drain_turn()

            if response is None:
                log.error(
                    "Inbox message %s for '%s' did not reach a terminal result; "
                    "leaving it unacknowledged for replay (state=%s)",
                    msg.id,
                    self.name,
                    self._state,
                )
                if msg.wait:
                    self.inbox.respond(
                        msg,
                        f"error: turn did not complete (session {self._state})",
                    )
                return

            if self._last_is_error:
                # A ResultMessage closes the SDK turn, but an error result is
                # not successful handling of the inbound event. Bounded retry
                # above has already been exhausted or ruled out. Keep the
                # cursor pinned so a restart can redeliver it instead of
                # silently converting the provider failure into message loss.
                log.error(
                    "Inbox message %s for '%s' ended in a terminal model "
                    "error after %d retries; leaving it unacknowledged",
                    msg.id,
                    self.name,
                    attempt,
                )
                if msg.wait:
                    self.inbox.respond(
                        msg,
                        response or "error: model turn failed",
                    )
                return

            if msg.wait:
                self.inbox.respond(msg, response)
            await self._ack_processed(msg)
        except Exception as e:
            # No ack: the message was not processed, so a restart replays it.
            log.error(f"Inbox processing failed for '{self.name}': {e}")
            if msg.wait:
                self.inbox.respond(msg, f"error: {e}")
            self._set_state("error")

    def _start_pending_rotation(self) -> None:
        """Start one coalesced background candidate preparation."""
        if self._rotation_task is not None:
            return
        self._rotation_task = asyncio.create_task(
            self._prepare_rotation(),
            name=f"rotation-connect-{self.name}",
        )

    async def _commit_ready_rotation(self, *, wait: bool = False) -> None:
        """Commit a prepared candidate, optionally waiting for an unsafe old client.

        Context-cap and manual rotations leave a healthy old client available,
        so the inbox keeps serving while preparation runs. A decode-error
        rotation has a spent response stream; in that case callers wait for the
        bounded candidate instead of querying a client known to be unusable.
        """
        task = self._rotation_task
        if task is None or (not wait and not task.done()):
            return

        try:
            candidate, reason = await task
        except Exception as e:
            # _prepare_rotation only raises after the bounded final recovery
            # has already emitted the terminal failure details.
            log.error(
                "Rotation failed terminally for '%s': %s",
                self.name,
                e,
                exc_info=True,
            )
            self._rotate_pending = False
            self._rotation_task = None
            self._set_state("error")
            get_registry().update(self.name, status="error")
            return

        try:
            await self._commit_rotation(candidate, reason)
        except asyncio.CancelledError:
            # If commit failed before publishing the candidate, do not leak it.
            if self._client is not candidate:
                await self._safe_disconnect(candidate)
            raise
        except Exception as e:
            if self._client is not candidate:
                await self._safe_disconnect(candidate)
            self._rotate_pending = False
            self._set_state("error")
            log.error(
                "Rotation commit failed terminally for '%s': %s",
                self.name,
                e,
                exc_info=True,
            )
            try:
                get_registry().update(self.name, status="error")
            except Exception:
                log.error(
                    "Could not persist terminal rotation state for '%s'",
                    self.name,
                    exc_info=True,
                )
        finally:
            self._rotation_task = None

    async def _stop_rotation_work(self) -> None:
        """Cancel/collect candidate and retired-client work before loop close."""
        task = self._rotation_task
        self._rotation_task = None
        if task is not None:
            if not task.done():
                task.cancel()
            try:
                candidate, _ = await task
            except asyncio.CancelledError:
                pass
            except Exception:
                pass
            else:
                if self._client is not candidate:
                    await self._safe_disconnect(candidate)

        retired = list(self._retired_client_tasks)
        if retired:
            await asyncio.gather(*retired, return_exceptions=True)

        detached = list(self._hard_timeout_tasks)
        if detached:
            for timed_out_task in detached:
                timed_out_task.cancel()
                asyncio.get_running_loop().call_soon(timed_out_task.cancel)
            _, pending = await asyncio.wait(
                detached,
                timeout=min(ROTATION_DISCONNECT_TIMEOUT, 0.1),
            )
            if pending:
                log.error(
                    "%d timed-out lifecycle task(s) for '%s' ignored adapter "
                    "cleanup and remain detached",
                    len(pending),
                    self.name,
                )

    async def _inbox_loop(self) -> None:
        loop = asyncio.get_running_loop()

        while True:
            await self._commit_ready_rotation()
            if self._state == "error":
                return
            msg = await loop.run_in_executor(
                None, lambda: self.inbox.recv(timeout=2.0)
            )
            # A candidate may have completed while recv() was blocked. Commit
            # it before starting the next turn so one turn always queries and
            # drains the same active client.
            await self._commit_ready_rotation()
            if self._state == "error":
                if msg is not None:
                    # Preparation can fail while recv() is blocked. Preserve
                    # the message in memory as well as leaving its cursor
                    # unacknowledged for the supervisor-driven restart.
                    self.inbox.push(msg, priority=True)
                return
            if msg is None:
                if self._keep_alive and self._keep_alive.is_set():
                    break
                # Act at idle - prepare a replacement when pending and the
                # queue is empty. Preparation runs beside this loop so a slow
                # connect cannot starve newly queued messages (#799).
                if self._rotate_pending and self.inbox.empty():
                    reason = self._rotate_reason
                    self._start_pending_rotation()
                    # Give a prompt, successful connect a chance to complete
                    # without waiting for the next inbox timeout.
                    await asyncio.sleep(0)
                    await self._commit_ready_rotation(
                        wait=(reason == "drain_decode_error")
                    )
                continue

            await self._process_message(msg)
            if self._state == "error":
                return
            if self._rotate_pending:
                reason = self._rotate_reason
                self._start_pending_rotation()
            else:
                reason = ""
            if reason == "drain_decode_error":
                # The old response reader is spent. Replace it before touching
                # another queued message, even under sustained inbox traffic.
                # Candidate preparation and cleanup retain their hard bounds;
                # terminal failure leaves following events unacknowledged.
                await self._commit_ready_rotation(wait=True)
                if self._state == "error":
                    return

    async def _run(self, startup_prompt: str | None = None) -> None:
        saved_id = load_resumable_session_id(self.name, self._session_model())
        resume_id = saved_id or None

        self._client = self._make_brain_session(resume=resume_id)

        try:
            connect_prompt = startup_prompt if not resume_id else None
            await self._client.connect(connect_prompt)
        except Exception as e:
            if resume_id:
                log.warning(f"Resume failed for '{self.name}', retrying fresh: {e}")
                save_session_id(self.name, "")
                self._client = self._make_brain_session(resume=None)
                await self._client.connect(startup_prompt)
            else:
                raise

        self._input_ready = asyncio.Event()
        self._set_state("running")
        registry = get_registry()
        registry.update(self.name, status="running")

        if startup_prompt and not resume_id:
            await self._drain_turn()
        elif startup_prompt and resume_id:
            await self._client.query(startup_prompt)
            await self._drain_turn()
        else:
            self._set_state("waiting_input")
            registry.update(self.name, status="idle")

        self._ready.set()
        log.info(f"Session '{self.name}' ready")

        inbox_task = asyncio.create_task(self._inbox_loop())

        self._keep_alive = asyncio.Event()
        try:
            await self._keep_alive.wait()
        finally:
            inbox_task.cancel()
            try:
                await inbox_task
            except asyncio.CancelledError:
                pass
            await self._stop_rotation_work()
            self._stop_ack_work()
            if self._client:
                await self._safe_disconnect(self._client)
                self._client = None
            self._set_state("stopped")
            registry.update(self.name, status="stopped")

    def _thread_target(self, startup_prompt: str | None) -> None:
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_until_complete(self._run(startup_prompt))
        except (KeyboardInterrupt, SystemExit) as e:
            log.info(f"Session '{self.name}' exiting: {type(e).__name__}")
            raise
        except Exception as e:
            log.error(f"Session '{self.name}' crashed: {e}", exc_info=True)
            self._set_state("error")
        finally:
            self._loop.close()
            self._loop = None

    def _start_subscription(self) -> None:
        """Subscribe this session to its own inbox topic (+ any extras).

        Every session is addressable: it registers one event-server deployment
        carrying ``inbox/<self>`` plus any extra topics (the manager's external
        resource topics). The drain feeds arriving messages into this session's
        in-process inbox queue.

        A failed initial registration is **never fatal** (#409). Registration
        used to be terminal for coordinators — a timed-out handshake re-raised,
        the session went to ``error`` state and died, taking out project leads
        and sub-agents at init. But the event server queues, sequences, and
        replays events, so a late registration simply resumes the stream from
        the saved cursor. A transient timeout must not kill the session: we boot
        now and retry registration in the background until it lands.
        """
        keys = [f"inbox/{self.name}"]
        for key in self._subscribe:
            if key not in keys:
                keys.append(key)
        # Clear any stop signal from a prior lifecycle so a reused Session can
        # subscribe again (Sessions are single-use today, but a stuck flag here
        # would silently disable all reconnects).
        self._sub_retry_stop.clear()
        try:
            from bobi.paths import bobi_root
            from bobi.subagent import _start_event_subscription
            # One fast probe on the boot path — a healthy registration lands in
            # ~ms. We deliberately DON'T burn the full in-band retry budget here:
            # blocking start() for tens of seconds on a slow event server would
            # stall the manager's boot and trip liveness probes. The background
            # loop below owns the patient, backed-off retries instead.
            self._subscription = _start_event_subscription(
                self.name, keys, bobi_root(), register_attempts=1)
        except Exception:
            log.warning(
                "Event subscription registration failed for '%s' — booting "
                "anyway and retrying in the background; queued events resume "
                "on reconnect", self.name, exc_info=True,
            )
            self._retry_subscription_in_background(keys)

    def _retry_subscription_in_background(self, keys: list[str]) -> None:
        """Keep retrying event-server registration off the boot path.

        Runs in a daemon thread with capped exponential backoff. Repeated
        failures are logged but never terminate the process. On success the
        subscription is wired in and the thread exits; ``stop()`` signals it to
        give up so a shutting-down session leaves no live client behind.
        """
        def _loop() -> None:
            from bobi.paths import bobi_root
            from bobi.subagent import _start_event_subscription
            delay = SUBSCRIPTION_RETRY_BASE
            attempt = 0
            while not self._sub_retry_stop.is_set():
                if self._sub_retry_stop.wait(delay):
                    return
                attempt += 1
                try:
                    # One attempt per loop iteration — the loop's own backoff is
                    # the retry cadence, so don't nest the in-band retry budget.
                    sub = _start_event_subscription(
                        self.name, keys, bobi_root(), register_attempts=1)
                except Exception as e:
                    delay = min(delay * 2, SUBSCRIPTION_RETRY_MAX)
                    log.warning(
                        "Background event-subscription retry #%d for '%s' "
                        "failed: %s — retrying in %.0fs",
                        attempt, self.name, e, delay,
                    )
                    continue
                # Wire in (or discard) under the lock so we can't race stop():
                # either stop() tears this client down, or we discard it here —
                # never leave a live client+drain that stop() already skipped.
                with self._sub_lock:
                    shutting_down = self._sub_retry_stop.is_set()
                    if not shutting_down:
                        self._subscription = sub
                if shutting_down:
                    sub.stop()
                    return
                log.info(
                    "Event subscription established for '%s' after %d "
                    "background retr%s", self.name, attempt,
                    "y" if attempt == 1 else "ies",
                )
                return

        self._sub_retry_thread = threading.Thread(
            target=_loop, daemon=True, name=f"sub-retry-{self.name}",
        )
        self._sub_retry_thread.start()

    def start(self, startup_prompt: str | None = None, timeout: int = 120) -> bool:
        """Start the session in a daemon thread.

        Registers the in-process inbox and starts the session's event
        subscription immediately so it is addressable (via ``inbox/<self>``)
        before the Claude client finishes connecting. Returns True when the
        session is ready for messages.
        """
        if self._thread and self._thread.is_alive():
            return True

        self.inbox.start()
        self._start_subscription()

        from bobi.sdk import compute_manifest_hash
        registry = get_registry()
        registry.register(
            SessionEntry(
                name=self.name,
                session_id=load_session_id(self.name) or "",
                role=self.role,
                cwd=self.cwd,
                status="starting",
                pid=os.getpid(),
                image_hash=compute_manifest_hash(),
            )
        )

        self._ready.clear()
        self._thread = threading.Thread(
            target=self._thread_target,
            args=(startup_prompt,),
            daemon=True,
            name=f"session-{self.name}",
        )
        self._thread.start()

        if self._ready.wait(timeout=timeout):
            return True
        log.error(f"Session '{self.name}' failed to start within {timeout}s")
        return False

    def get_session_id(self) -> str:
        return load_session_id(self.name)

    def stop(self) -> None:
        if self._keep_alive:
            self._keep_alive.set()
        # Tell any background registration retry to give up before we tear the
        # subscription down, so it can't wire in a fresh client mid-shutdown.
        self._sub_retry_stop.set()
        if self._sub_retry_thread:
            self._sub_retry_thread.join(timeout=5)
            self._sub_retry_thread = None
        if self._thread:
            self._thread.join(timeout=15)
        # Tear down the event subscription (WS client + drain thread) BEFORE
        # unregistering the inbox, so the drain can't push into — or warn about —
        # a closed inbox on its way out. Swap under the lock: a background retry
        # that registered concurrently either handed its client to us here, or
        # saw the stop flag and tore its own down — never both, never neither.
        with self._sub_lock:
            sub, self._subscription = self._subscription, None
        if sub is not None:
            sub.stop()
        self.inbox.close()

    def is_alive(self) -> bool:
        return (
            self._thread is not None
            and self._thread.is_alive()
            and self._state not in ("stopped", "error")
        )

    def wait_until_ready(self, timeout: int = 60) -> bool:
        return self._ready.wait(timeout=timeout)
